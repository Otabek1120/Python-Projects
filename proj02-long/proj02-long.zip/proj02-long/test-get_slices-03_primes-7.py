#! /usr/bin/python3

from utils import *



data = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47]
n    = 7

print(f"INPUT LIST: {data}")
print(f"N:          {n}")
print()


print("--- SLICES ---")
print(get_slices(data, n))
print()


print()
print("TESTCASE COMPLETED")


